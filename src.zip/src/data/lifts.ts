export type LiftId = string;

export const CATALOG_BY_ID: Record<LiftId, {
  name: string;
  C: number;          // 0–100 ceiling potential (systemic transfer)
  type?: 'barbell' | 'dumbbell' | 'machine' | 'isolation';
}> = {
  'bb_bench': { name: 'Barbell Bench Press', C: 70, type: 'barbell' },
  'db_bench': { name: 'Dumbbell Bench Press', C: 60, type: 'dumbbell' },
  'squat_hb': { name: 'High-bar Squat', C: 95, type: 'barbell' },
  'dl_conv':  { name: 'Conventional Deadlift', C: 100, type: 'barbell' },
  // …add the rest
};
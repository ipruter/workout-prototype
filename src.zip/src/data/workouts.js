// src/data/workouts.js
// Canonical workout names, matching CATALOG_BY_ID + WORKOUT_TARGETS
export const WORKOUTS = [
  "Ab Wheel Rollout",
  "Back Squat",
  "Seated French Press",
  "Front Squat",
  "Goblet Squat",
  "Bulgarian Split Squat",
  "Lunge (Walking)",
  "Leg Press",
  "Leg Extension",
  "Seated Leg Curl",
  "Romanian Deadlift",
  "Conventional Deadlift",
  "Hip Thrust",
  "Calf Raise (Standing)",
  "Calf Raise (Seated)",
  "Donkey Calf Raise",

  "Bench Press (Barbell)",
  "Bench Press (Dumbbell)",
  "Incline Bench Press (Barbell)",
  "Overhead Press (Barbell)",
  "Overhead Press (Dumbbell)",
  "Dip",
  "Push-Up",
  "Overhead Triceps Extension",
  "Triceps Pushdown",

  "Barbell Row",
  "Dumbbell Row",
  "Seated Cable Row",
  "Lat Pulldown",
  "Chin-Up",
  "Face Pull",
  "Reverse Fly",
  "Lateral Raise",
  "Front Raise",
  "Upright Row (Wide)",

  "Biceps Curl (Barbell)",
  "Biceps Curl (Dumbbell)",

  "Abduction Machine",
  "Cable Crunch",
  "Hanging Leg Raise",
  "Plank",
  "Russian Twist",
  "Barbell Shrug",
  
].sort((a, b) => a.localeCompare(b));


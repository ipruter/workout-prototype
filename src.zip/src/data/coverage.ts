// src/data/coverage.ts
export type RegionId = string;
import type { LiftId } from "./lifts"; 

// how much 1 set of L contributes to region R (fractional effective set)
export const coverageByLR: Record<LiftId, Record<RegionId, number>> = {
  bb_bench: { chest: 1.0, front_delt: 0.35, triceps: 0.35 },
  db_bench: { chest: 1.0, front_delt: 0.25, triceps: 0.25 },
  squat_hb: { quads: 0.9, glutes: 0.4, spinal_erectors: 0.3 },
  dl_conv:  { glutes: 0.6, hamstrings: 0.6, spinal_erectors: 0.9 },
  // …
};

// how directly the lift targets R (used in G pre-mult)
export const directness: Record<LiftId, Record<RegionId, number>> = {
  bb_bench: { chest: 0.8, front_delt: 0.5, triceps: 0.5 },
  db_bench: { chest: 0.9, front_delt: 0.45, triceps: 0.45 },
  // …
};

// relative ROM / stretch for that region in this lift (0..1)
export const rom: Record<LiftId, Record<RegionId, number>> = {
  bb_bench: { chest: 0.8, front_delt: 0.5, triceps: 0.5 },
  db_bench: { chest: 0.9, front_delt: 0.55, triceps: 0.5 },
  // …
};

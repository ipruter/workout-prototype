export function isFluffLift(lift) {
if (typeof lift?.isFluff === 'boolean') return lift.isFluff;
return Number(lift?.ceiling || 0) <= 10; // heuristic fallback
}


export function normalizeCeiling(C) {
const c = Math.max(1, Math.min(100, Number(C || 0)));
return c / 100; // 0..1
}


export function computeGlobalCNS({ catalogById = {}, weeklySets = [] }) {
let wSum = 0, wCount = 0;
for (const row of weeklySets) {
const lift = catalogById[row.liftId];
if (!lift) continue;
const Cn = normalizeCeiling(lift.ceiling); // 0..1
const s = Number(row.sets || 0);
wSum += Cn * s * (row.effortWeight ?? 1) * (row.repStrengthWeight ?? 1);
wCount += s;
}
if (!wCount) return 0;
return Math.round((wSum / wCount) * 100); // 0..100
}


export function computeHypertrophySets({ catalogById = {}, weeklySets = [], coverageByLR = {}, wEffort = ()=>1, wHyp = ()=>1, alpha = 0.30, directness = {}, rom = {} }) {
// Baseline hypertrophy sets WITHOUT G-diminish (used as a component of adjusted versions)
let perRegion = {};
for (const row of weeklySets) {
const { liftId, sets = 0, reps, RIR } = row;
const lift = catalogById[liftId];
if (!lift) continue;
const covMap = coverageByLR[liftId] || {};
const eW = wEffort(RIR);
const hW = wHyp(reps);
for (const R in covMap) {
const cov = Number(covMap[R] || 0);
const d = Number(directness?.[liftId]?.[R] ?? cov); // fallback: use cov as proxy
const r = Number(rom?.[liftId]?.[R] ?? 1);
const gReg = normalizeCeiling(lift.ceiling) * d * r; // 0..1
const preMult = 1 + alpha * gReg;
perRegion[R] = (perRegion[R] || 0) + cov * sets * eW * hW * preMult;
}
}
return perRegion; // { regionId: effectiveSets }
}


export function computeGShareByRegion({ catalogById = {}, weeklySets = [], coverageByLR = {}, isHighG = (lift)=> normalizeCeiling(lift.ceiling) >= 0.5, isStrengthRep = (reps)=> reps <= 6 }) {
// Fraction of a region's weekly volume that is high-G AND in strength rep ranges
const num = {}, den = {};
for (const row of weeklySets) {
const { liftId, sets = 0, reps } = row;
const lift = catalogById[liftId];
if (!lift) continue;
const covMap = coverageByLR[liftId] || {};
const addToNum = isHighG(lift) && isStrengthRep(reps);
for (const R in covMap) {
const cov = Number(covMap[R] || 0);
den[R] = (den[R] || 0) + cov * sets;
if (addToNum) num[R] = (num[R] || 0) + cov * sets;
}
}
const out = {};
for (const R in den) {
out[R] = den[R] > 0 ? (num[R] || 0) / den[R] : 0;
}
return out; // { regionId: 0..1 }
}

export function diminishFactor(gshare, threshold = 0.40, gamma = 3.0, floor = 0.60) {
  const g = Number.isFinite(gshare) ? Math.max(0, Math.min(1, gshare)) : 0;
  const t = Math.max(0, Math.min(0.95, threshold)); // avoid divide-by-zero
  if (g <= t) return 1;

  const x = (g - t) / (1 - t);                     // 0..1 beyond threshold
  const mult = floor + (1 - floor) * Math.exp(-gamma * x); // smooth exponential
  return Math.max(floor, Math.min(1, mult));
}

export function computeGAdjustedSets(params) {
  const {
    threshold = 0.40,      // natty default
    gamma = 3.0,
    floor = 0.60
  } = params || {};

  // Base effective sets (already includes pre-mult 1 + alpha*gReg from your function)
  const basePerRegion = computeHypertrophySets(params);

  // Fraction of volume that’s high-G & strength-range per region
  const gshareByR = computeGShareByRegion(params);

  // Apply diminish multiplier per region
  const out = {};
  for (const R in basePerRegion) {
    const gshare = gshareByR[R] || 0;
    const mult = diminishFactor(gshare, threshold, gamma, floor);
    // keep a tidy 2-decimal number
    out[R] = Math.round(basePerRegion[R] * mult * 100) / 100;
  }
  return out;
}

// Keep your ProgramMetrics.jsx happy:
export { computeGAdjustedSets as computeGCeiling };
export { computeGAdjustedSets as computeHypertrophyAdjusted };
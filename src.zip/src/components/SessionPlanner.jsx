// src/components/SessionPlanner.jsx
import { useEffect, useMemo, useState } from "react";
import { CATALOG_BY_ID } from "../data/lifts";
import {
  estimateExerciseMinutes,
  totalMinutes,
  getKnown1RM,
  setKnown1RM,
  estimate1RMFromWeight,
  weightFrom1RM,
} from "../utils/timeBudget";

// ---------- one exercise row card ----------
function ExerciseCard({
  row,
  onChange,
  onRemove,
  withCheckbox = false,
  checked = false,
  onToggleCheck = null,
}) {
  const lift = CATALOG_BY_ID[row.liftId];

  // Base 1RM to use for deriving weight (row.orm first, else stored)
  const baseOneRM = Number.isFinite(row.orm) ? row.orm : getKnown1RM(row.liftId) ?? null;

  // Derived working weight (if row.weight is null we show this)
  const derivedWeight = useMemo(() => {
    if (!Number.isFinite(baseOneRM)) return null;
    return weightFrom1RM({
      oneRM: baseOneRM,
      intensityPct: row.intensityPct,
      sets: row.sets,
    });
  }, [baseOneRM, row.intensityPct, row.sets]);

  // Keep weight derived (null in state) when these change
  function recalcAndKeepDerived(patch = {}) {
    onChange({ ...row, ...patch, weight: null });
  }

  // Minutes display uses your helper (works with either explicit or derived weight)
  const minutes = estimateExerciseMinutes({
    liftId: row.liftId,
    sets: row.sets,
    intensityPct: row.intensityPct,
    weight: row.weight ?? derivedWeight ?? null,
    orm: baseOneRM ?? null,
  });

  // Quick e1RM display from what’s currently in the row (optional)
  const e1rm = estimate1RMFromWeight({
    weight: row.weight ?? derivedWeight ?? null,
    intensityPct: row.intensityPct,
    sets: row.sets,
  });

  return (
    <div style={{ border: "1px solid #e3e3e3", borderRadius: 12, padding: 12, marginTop: 10 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          {withCheckbox && (
            <input
              type="checkbox"
              checked={!!checked}
              onChange={(e) => onToggleCheck?.(e.target.checked)}
            />
          )}
          <div style={{ fontWeight: 600 }}>{lift?.name || row.liftId}</div>
        </div>
        <button onClick={onRemove} aria-label="remove">✕</button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(6, minmax(0, 1fr))", gap: 8, marginTop: 10 }}>
        {/* Sets */}
        <label style={{ fontSize: 12 }}>
          <div>Sets</div>
          <input
            type="number"
            min="1"
            value={row.sets ?? 1}
            onChange={(e) => {
              const sets = Math.max(1, Number(e.target.value) || 1);
              recalcAndKeepDerived({ sets });
            }}
          />
        </label>

        {/* Reps (informational here) */}
        <label style={{ fontSize: 12 }}>
          <div>Reps</div>
          <input
            type="number"
            min="1"
            value={row.reps ?? 1}
            onChange={(e) => onChange({ ...row, reps: Math.max(1, Number(e.target.value) || 1) })}
          />
        </label>

        {/* Intensity % */}
        <label style={{ display: "grid", gap: 4 }}>
          <div>Intensity %</div>
          <input
            type="number"
            step="1"
            value={row.intensityPct ?? ""}
            onChange={(e) => {
              const intensityPct = Number.isFinite(+e.target.value) ? +e.target.value : null;
              recalcAndKeepDerived({ intensityPct });
            }}
            style={{ width: 100 }}
          />
        </label>

        {/* Weight (always shows either explicit weight or derived display) */}
        <label style={{ fontSize: 12 }}>
          <div>Weight</div>
          <input
            type="number"
            step="5"
            placeholder="e.g. 225"
            value={row.weight ?? (derivedWeight ?? "")}
            onChange={(e) => {
              const val = e.target.value;
              if (val === "") {
                // cleared → keep weight derived
                onChange({ ...row, weight: null });
                return;
              }
              const w = +val;
              if (!Number.isFinite(w) || w <= 0) return;

              // User typed a working weight → infer 1RM and persist it
              const inferred = estimate1RMFromWeight({
                weight: w,
                intensityPct: row.intensityPct,
                sets: row.sets,
              });
              if (Number.isFinite(inferred) && inferred > 0) {
                setKnown1RM(row.liftId, Math.round(inferred));
              }

              // Store inferred on the row too and keep weight derived (null)
              onChange({
                ...row,
                orm: Number.isFinite(inferred) ? Math.round(inferred) : row.orm ?? null,
                weight: null,
              });
            }}
          />
        </label>

        {/* 1RM (manual) */}
        <label style={{ fontSize: 12 }}>
          <div>1RM (manual)</div>
          <input
            type="number"
            placeholder="optional"
            value={row.orm ?? ""}
            onChange={(e) => {
              const nextOrm = e.target.value === "" ? null : +e.target.value;
              if (Number.isFinite(nextOrm) && nextOrm > 0) {
                setKnown1RM(row.liftId, Math.round(nextOrm));
              }
              // keep weight derived after 1RM edits
              recalcAndKeepDerived({ orm: Number.isFinite(nextOrm) ? Math.round(nextOrm) : null });
            }}
          />
        </label>

        {/* Minute estimate + e1RM */}
        <div style={{ alignSelf: "end", fontSize: 12, textAlign: "right" }}>
          ≈ {minutes.toFixed(1)} min
          <div style={{ opacity: 0.75 }}>
            e1RM: {e1rm ? Math.round(e1rm) : "—"}
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- planner ----------
export default function SessionPlanner({
  targetMinutes = 45,
  value = [],
  onChange,
  hidePicker = false,
  successMarks = null,
  onToggleSuccess = null,
}) {
  const [rows, setRows] = useState(value);
  const [selectId, setSelectId] = useState("");

  useEffect(() => { setRows(value || []); }, [value]);

  const opts = useMemo(
    () =>
      Object.entries(CATALOG_BY_ID)
        .map(([id, o]) => ({ id, name: o.name }))
        .sort((a, b) => a.name.localeCompare(b.name)),
    []
  );

  function commit(next) {
    setRows(next);
    onChange?.(next);
  }

  function addSelected() {
    if (!selectId) return;
    const knownOrm = getKnown1RM(selectId);
    const defaultRow = {
      liftId: selectId,
      sets: 3,
      reps: 6,
      intensityPct: 75,
      weight: null,           // keep derived
      orm: knownOrm ?? null,  // seeds derived weight
    };
    commit([...rows, defaultRow]);
    setSelectId("");
  }

  function removeAt(i) {
    const next = rows.slice();
    next.splice(i, 1);
    commit(next);
  }

  const used = totalMinutes(rows);
  const remaining = Math.max(0, targetMinutes - used);

  return (
    <section>
      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
        {!hidePicker && (
          <>
            <select value={selectId} onChange={(e) => setSelectId(e.target.value)}>
              <option value="">Add workout…</option>
              {opts.map((o) => (
                <option key={o.id} value={o.id}>
                  {o.name}
                </option>
              ))}
            </select>
            <button onClick={addSelected} disabled={!selectId}>
              Add
            </button>
          </>
        )}
        <div style={{ marginLeft: "auto", fontWeight: 600 }}>
          {used.toFixed(1)} / {targetMinutes} min
          {remaining === 0 ? "" : `  (left: ${remaining.toFixed(1)})`}
        </div>
      </div>

      {rows.map((r, i) => (
        <ExerciseCard
          key={i}
          row={r}
          onChange={(updated) => {
            const next = rows.slice();
            next[i] = updated;
            commit(next);
          }}
          onRemove={() => removeAt(i)}
          withCheckbox={Array.isArray(successMarks)}
          checked={successMarks?.[i] || false}
          onToggleCheck={(val) => onToggleSuccess?.(i, val)}
        />
      ))}
    </section>
  );
}
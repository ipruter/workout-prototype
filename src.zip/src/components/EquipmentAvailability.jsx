// src/components/EquipmentAvailability.jsx
import { useEffect, useState } from "react";
import { CHECKBOX_KEYS, buildBlockedSet } from "../utils/equipmentFallback";

export default function EquipmentAvailability({ onChange }) {
  // Persisted booleans keyed by checkbox name
  const [blocked, setBlocked] = useState({
    barbells: false,
    machines: false,
    dumbbells: false,
    assisted: false,
  });

  // LOAD from localStorage on mount
  useEffect(() => {
    try {
      const raw = localStorage.getItem("equipment-unavailable");
      const arr = raw ? JSON.parse(raw) : [];
      if (Array.isArray(arr)) {
        setBlocked({
          barbells: arr.includes(CHECKBOX_KEYS.barbells),
          machines: arr.includes(CHECKBOX_KEYS.machines),
          dumbbells: arr.includes(CHECKBOX_KEYS.dumbbells),
          assisted: arr.includes(CHECKBOX_KEYS.assisted),
        });
      }
    } catch {}
  }, []);

  // SAVE to localStorage + bubble up a Set to parent
  useEffect(() => {
    const keys = Object.keys(blocked).filter((k) => blocked[k]);
    localStorage.setItem("equipment-unavailable", JSON.stringify(keys));
    onChange?.(buildBlockedSet(blocked));
  }, [blocked, onChange]);

  return (
    <div>
      {Object.keys(CHECKBOX_KEYS).map((k) => (
        <label key={k} style={{ display: "block", margin: "6px 0" }}>
          <input
            type="checkbox"
            checked={!!blocked[k]}
            onChange={(e) =>
              setBlocked((s) => ({ ...s, [k]: e.target.checked }))
            }
          />{" "}
          {k === "assisted"
            ? "Assisted station (if needed for pull ups and dips)"
            : k.charAt(0).toUpperCase() + k.slice(1)}
        </label>
      ))}
    </div>
  );
}

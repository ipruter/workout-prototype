import React from 'react';
import {
computeGlobalCNS,
computeHypertrophySets,
computeHypertrophyAdjusted,
computeGCeiling
} from '../utils/metrics.js';


/**
* ProgramMetrics (revised)
* - Shows raw per‑region sets (no G) and ceiling‑adjusted per‑region sets (Natty/Enhanced)
* - Filters lists by the current heatmap view via visibleRegionIds
* - Keeps the global CNS and G displays
*/
export default function ProgramMetrics({ catalogById, weeklySets, coverageByLR, wEffort, wHyp, directness, rom, visibleRegionIds = [] }) {
const globalCNS = computeGlobalCNS({ catalogById, weeklySets });
const gScore = computeGCeiling({ catalogById, weeklySets });
const nattySets  = computeGCeiling({ ...params, threshold: 0.40 });
const gearedSets = computeGCeiling({ ...params, threshold: 0.20 });


// Raw (no G) per-region effective sets (alpha=0 disables preMult)
const hypRawAll = computeHypertrophySets({ catalogById, weeklySets, coverageByLR, wEffort, wHyp, alpha: 0, directness, rom });


// Ceiling‑adjusted per‑region effective sets
const hypNattyAll = computeHypertrophyAdjusted({ catalogById, weeklySets, coverageByLR, wEffort, wHyp, directness, rom, profile: 'natty' });
const hypEnhAll = computeHypertrophyAdjusted({ catalogById, weeklySets, coverageByLR, wEffort, wHyp, directness, rom, profile: 'enhanced' });


// Filter by current heatmap view (front/back/deep‑front/deep‑back)
const isVisible = (r) => !visibleRegionIds.length || visibleRegionIds.includes(r);
const hypRaw = Object.fromEntries(Object.entries(hypRawAll).filter(([r]) => isVisible(r)));
const hypNatty = Object.fromEntries(Object.entries(hypNattyAll).filter(([r]) => isVisible(r)));
const hypEnh = Object.fromEntries(Object.entries(hypEnhAll).filter(([r]) => isVisible(r)));


const Box = ({ title, value, suffix }) => (
<div className="p-4 rounded-2xl border bg-white/70 shadow-sm">
<div className="text-xs uppercase tracking-wide text-slate-500 mb-1">{title}</div>
<div className="text-2xl font-bold text-slate-800">
{value}{suffix ? <span className="text-sm ml-1">{suffix}</span> : null}
</div>
</div>
);


const RegionList = ({ title, data }) => (
<div>
<div className="text-xs uppercase text-slate-500 mb-2">{title}</div>
<ul className="space-y-1 text-sm">
{Object.entries(data).map(([region, val]) => (
region.startsWith('__') ? null : (
<li key={region} className="flex justify-between"><span>{region}</span><span className="font-mono">{val.toFixed(1)}</span></li>
)
))}
</ul>
</div>
);


return (
<div className="space-y-4">
<div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
<Box title="Global CNS Score" value={globalCNS} suffix="%" />
<Box title="G — Ceiling Score" value={gScore} suffix="%" />
<Box title="Current View" value={visibleRegionIds.length ? `${visibleRegionIds.length} regions` : 'All regions'} />
</div>


<div className="rounded-2xl border p-4 bg-white/70 space-y-4">
<div className="text-sm font-semibold">Sets by Region (Filtered to Current View)</div>
<div className="grid grid-cols-1 md:grid-cols-3 gap-4">
<RegionList title="Raw (no G modifier)" data={hypRaw} />
<RegionList title="Effective (Natty)" data={hypNatty} />
<RegionList title="Effective (Enhanced)" data={hypEnh} />
</div>
</div>
</div>
);
}